<h2 id="atospp-toc" class="auto-tos-pp tospptocheading">Contents:</h2>
<ol class="auto-tos-pp tospptoc">
    <li><a href="#atospp-terms"><?php echo $atospp_tos_heading; ?></a></li>
    <li><a href="#atospp-privacy"><?php echo $atospp_pp_heading; ?></a></li>
</ol>
<div class="auto-tos-pp-separator" style="width: 100%; border-bottom: 1px black solid; margin: 20px 0 20px 0;"></div>
<?php
include __DIR__ . DIRECTORY_SEPARATOR . 'terms-of-service.php';
?>
<p><a class="auto-tos-pp-back-to-top" href="#atospp-toc">Back to top</a></p>
<div class="auto-tos-pp-separator" style="width: 100%; border-bottom: 1px black solid; margin: 20px 0 20px 0;"></div>
<?php
include __DIR__ . DIRECTORY_SEPARATOR . 'privacy-policy.php';
?>
<p><a class="auto-tos-pp-back-to-top" href="#atospp-toc">Back to top</a></p>
