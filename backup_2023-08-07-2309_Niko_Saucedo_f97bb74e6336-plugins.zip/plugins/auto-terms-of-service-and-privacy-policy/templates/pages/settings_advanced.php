<?php
include( __DIR__ . DIRECTORY_SEPARATOR . 'settings.php' );